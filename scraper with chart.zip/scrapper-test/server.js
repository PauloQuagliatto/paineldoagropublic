import express from 'express'
import cors from 'cors'
import bodyParser from 'body-parser'
import './lib/cron'
import products from './lib/routes/api/products'
import { connectToMongo } from './lib/mongoDb'

const app = express()

app.use(cors())
app.use(bodyParser.json())

connectToMongo()

app.use('/api/mongo/products', products)

const port = process.env.port || 5000

app.listen(port, () => console.log(`Server starts on port: ${port}`))