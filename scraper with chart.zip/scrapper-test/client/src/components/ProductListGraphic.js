import React, { useEffect, useState } from 'react'
import { connect } from 'react-redux'
import { Line } from 'react-chartjs-2'
import selectProducts from '../selectors/products'

const ProductListGraphic = (props) => {
    const [chartData, setChartData] = useState({})
    
    const chart = () => {
        let productsLabels = []
        let productsData = []
        for (let i = 0; i < props.products.length; i++){
            productsLabels.push(props.products[i])
            for(let j = 0; props.products[i].informantion.length; j++){
                productsData.push(props.products[i].informantion[j].price)
            }
        }
        setChartData({
            chartData: {
                labels: productsLabels,
                datasets: [
                {
                    label: 'Preço',
                    data: productsData
                }
                ]
            }
        })
    }

    useEffect(() => {
        chart()
    })
        return(
        <Line data={chartData.data}
            options={{maintainAspectRatio: true}}
        />
        )
}

const mapStateToProps = (state)=>{
    return { products: selectProducts(state.products, state.filters) }
}

export default connect(mapStateToProps)(ProductListGraphic)