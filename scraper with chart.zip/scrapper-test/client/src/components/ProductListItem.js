import React from 'react'

const ProductListItem = (product) => (
    <div className="list-item">
        <div>
            <h3 className="list-item__title">{product.name}</h3>
        </div>
    </div>
)

export { ProductListItem as default }