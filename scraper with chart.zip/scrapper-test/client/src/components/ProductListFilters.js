import React from 'react'
import { connect } from 'react-redux'
import { setTextFilter, setStartDate, setEndDate } from '../actions/filters'
import { DateRangePicker } from 'react-dates'

class ProductListFilters extends React.Component {
    state = {
        calendarFocused: null,
        displayFormat: 'DD/MM/YYYY',
        startDateText: 'Dia Inicial',
        endDateText: 'Dia Final'
    }
    onDatesChange = ({ startDate, endDate }) => {
        this.props.dispatch(setStartDate(startDate))
        this.props.dispatch(setEndDate(endDate))
    }
    onFocusChange = (calendarFocused) => {
        this.setState(() => ({ calendarFocused }))
    }
    render() {
        return (
            <div className="content-container content-container__bigger">
                <div className="input-group">
                    <div className="input-group__item">
                        <input
                            type="text"
                            className="text-input"
                            placeholder="Selcione o Produto"
                            value={this.props.filters.text}
                            onChange={(e) => {
                                this.props.dispatch(setTextFilter(e.target.value))
                            }}
                        />
                    </div>
                    <div className="input-group__item">
                        <DateRangePicker
                            startDate={this.props.filters.startDate}
                            startDateId="start"
                            endDate={this.props.filters.endDate}
                            endDateId="end"
                            onDatesChange={this.onDatesChange}
                            focusedInput={this.state.calendarFocused}
                            onFocusChange={this.onFocusChange}
                            showClearDates={true}
                            numberOfMonths={1}
                            isOutsideRange={() => false}
                            startDatePlaceholderText={this.state.startDateText}
                            endDatePlaceholderText={this.state.endDateText}
                            displayFormat={this.state.displayFormat}
                        />
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return { filters: state.filters }
}

export default connect(mapStateToProps)(ProductListFilters)