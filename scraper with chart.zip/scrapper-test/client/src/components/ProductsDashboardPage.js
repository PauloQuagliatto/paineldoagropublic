import React from 'react'
import ProductList from './ProductList'
import ProductListFilters from './ProductListFilters'
import ProductListGraphic from './ProductListGraphic'

const ProductsDashboardPage = () => (
      <div>
        <ProductListGraphic />
        <ProductListFilters />
        <ProductList />
      </div>
)

export { ProductsDashboardPage as default }