// News Reducer

const newsReducerDefaultState = {
  news: [],
  loading: false
}

export default (state = newsReducerDefaultState, action) => {
  switch (action.type) {
    case 'SET_NEWS':
      return action.news
    default:
      return state;
  }
}
