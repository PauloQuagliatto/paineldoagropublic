import axios from 'axios'

//SET_PRODUCTS
const setProducts = (products) => ({
  type: 'SET_PRODUCTS',
  products
})

//START_SET_PRODUCTS
export const startSetProducts = () => {
  return (dispatch) => {
    const products = []
    return axios.get('api/mongo/products')
                .then(res => res.data.map((theData) => 
                  (products.push(theData))))
                .then(dispatch(setProducts(products)))
  }
}