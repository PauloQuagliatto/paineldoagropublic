import moment from 'moment'

// Get visible products

export default (products, { text, startDate, endDate, sortBy }) => {
  return products.filter((produtct) => {
    const createdAtMoment = moment(produtct.createdAt)
    const startDateMatch = startDate ? startDate.isSameOrBefore(createdAtMoment, 'day') : true
    const endDateMatch = endDate ? endDate.isSameOrAfter(createdAtMoment, 'day') : true
    const textMatch = produtct.name.toLowerCase().includes(text.toLowerCase())


    return startDateMatch && endDateMatch && textMatch
  // eslint-disable-next-line array-callback-return
  }).sort((a, b) => {
    if (sortBy === 'date') {
      return a.createdAt > b.createdAt ? 1 : -1
    }
  })
}
