import React from 'react'
import ProductsDashboardPage from './components/ProductsDashboardPage'

const App = () => (
  <div>
    <ProductsDashboardPage />
  </div>
)

export default App
