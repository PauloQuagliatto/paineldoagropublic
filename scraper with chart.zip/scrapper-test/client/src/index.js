import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import configureStore from './store/configureStore'
import 'react-dates/lib/css/_datepicker.css'
import 'react-dates/initialize'
import App from './App'
import LoadingPage from './components/LoadingPage'
import { startSetProducts }from './actions/products'
import 'react-dates/lib/css/_datepicker.css'
import 'react-dates/initialize'

const store = configureStore()
const app = (
  <Provider store={store}>
    <App />
  </Provider>
)
let hasRendered = false
const renderApp = () => {
  if(!hasRendered){
    ReactDOM.render(app, document.getElementById('root'))
    hasRendered = true
  }
}
ReactDOM.render(<LoadingPage />, document.getElementById('root'))

store.dispatch(startSetProducts(), console.log('store working')).then(() => renderApp())